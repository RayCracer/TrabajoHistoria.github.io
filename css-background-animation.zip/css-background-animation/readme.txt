This template / effect / code has been created by Sépion.
You can customize and check it out on its original site on the following link:
https://codepen.io/Sepion/pen/ZQJyeq

Thank you